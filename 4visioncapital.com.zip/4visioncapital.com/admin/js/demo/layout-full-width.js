
// LAYOUT FULL WIDTH
// ====================================================================
// This file should not be included in your project.
// This is just a sample how to initialize plugins or components.
//



 $(document).ready(function() {
    $('#scrolldiv').slimscroll({
        height: 'auto'
    });
});
